package com.cg.lab2.dao;

import java.util.List;

import com.cg.lab2.dto.Trainee;

public interface ITraineeDao 
{
	public int insertTrainee(Trainee trainee);
	public void deleteTrainee(int id);
	public void updateTrainee();
	public List<Trainee> showAllTrainee();
	public Trainee searchTrainee(int id);
}
