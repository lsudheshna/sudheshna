package com.cg.lab2.cntrl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.lab2.dto.Trainee;
import com.cg.lab2.service.ITraineeService;

@Controller
public class TraineeController 
{
	@Autowired
	ITraineeService traineeservice;
	@RequestMapping(value="showall",method=RequestMethod.GET)
	public String showMenu()
	{
		return "menu";
	}
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String traineeForm(@ModelAttribute("my") Trainee trainee, 
			Map<String,Object> model) 
		
	{
		List<String> myDomain = new ArrayList<>();
		myDomain.add("Oracle");
		myDomain.add("Java");
		myDomain.add("Testing");
		model.put("domain",myDomain);
		return "add";
	}
	
	@RequestMapping(value="insertdata", method=RequestMethod.POST)
	public String insertTrainee(@ModelAttribute("my")Trainee trainee)
	{
		int id=traineeservice.insertTrainee(trainee);
		return "success";
	}
	
	@RequestMapping(value="delete", method=RequestMethod.GET)
	public String deleteTrainee()
	{
		return "delete";
	}
	
	@RequestMapping(value="deletedata", method=RequestMethod.GET)
	public ModelAndView deleteTraineeData(@RequestParam("id")int eid)
	{
		Trainee t=traineeservice.searchTrainee(eid);
		return new ModelAndView("showdelete", "temp", t);
	}
	@RequestMapping(value="deleteall", method=RequestMethod.GET)
	public String deleteAll(@RequestParam("iid")int eid)
	{
		traineeservice.deleteTrainee(eid);
		return "success";
	}
}
