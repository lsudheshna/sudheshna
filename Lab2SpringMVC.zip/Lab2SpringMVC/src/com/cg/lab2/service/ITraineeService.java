package com.cg.lab2.service;

import java.util.List;

import com.cg.lab2.dto.Trainee;

public interface ITraineeService 
{
	public int insertTrainee(Trainee trainee);
	public void deleteTrainee(int id);
	public void updateTrainee();
	public List<Trainee> showAllTrainee();
	public Trainee searchTrainee(int id);
}
