package com.cg.springmvc1.dao;

import java.util.List;

import javax.persistence.*;

import org.springframework.stereotype.Repository;

import com.cg.springmvc1.dto.Employee;

@Repository("employeedao")
public class EmployeeDao implements IEmployeeDao 
{
	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public void addEmployeeData(Employee emp)
	{
		// TODO Auto-generated method stub
		entitymanager.persist(emp);
		entitymanager.flush();
	}

	@Override
	public List<Employee> showAllEmployee() 
	{
		Query query1=entitymanager.createQuery("FROM Employee");
		List<Employee> myList= query1.getResultList();
		return myList;
	}

	@Override
	public void deleteEmployee(int empId) 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public int updateEmployee(Employee emp)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Employee searchEmployee(int id)
	{
		// TODO Auto-generated method stub
		return null;
	}

}
