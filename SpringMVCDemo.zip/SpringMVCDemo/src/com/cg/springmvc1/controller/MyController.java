package com.cg.springmvc1.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvc1.dto.Employee;
import com.cg.springmvc1.service.IEmployeeService;

@Controller
public class MyController//user-defined controller 
{
	@Autowired
	IEmployeeService employeeservice;
	@RequestMapping(value="all",method=RequestMethod.GET)//url-mapping:all is forwarded from index.jsp 
	public String getAll()
	{
		return "home";
	}
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addEmployee(@ModelAttribute("my") Employee emp
			,Map<String,Object> model)
	{
		List<String> myDeg=new ArrayList<>();
		myDeg.add("Software Eng");
		myDeg.add("Sr consultant");
		myDeg.add("Manager");
		model.put("deg",myDeg);
		return "addemployee";
	}
	@RequestMapping(value="insertdata",method=RequestMethod.POST)
	public String insertEmployee(@ModelAttribute("my") Employee emp)
	{
		employeeservice.addEmployeeData(emp);
		return "success";
	}
	@RequestMapping(value="show",method=RequestMethod.GET)
	public ModelAndView showAllEmployee()
	{
		List<Employee>myAllData=employeeservice.showAllEmployee();
		return new ModelAndView("showall","temp",myAllData);
		
	}
}
