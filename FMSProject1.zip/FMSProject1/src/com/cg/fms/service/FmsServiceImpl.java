package com.cg.fms.service;

import java.util.List;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.bean.TrainingBean;
import com.cg.fms.dao.FmsDaoImpl;
import com.cg.fms.dao.IFmsDao;
import com.cg.fms.exception.FeedbackException;

public class FmsServiceImpl implements IFmsService {

	IFmsDao fmsDao = new FmsDaoImpl();
	@Override
	public int insertFeedback(FeedbackBean feedback) throws FeedbackException {
		return fmsDao.insertFeedback(feedback);
	}
	@Override
	public List<EmployeeBean> getEmployeeId(String skill)throws FeedbackException {
		return fmsDao.getEmployeeId(skill);
	}
	@Override
	public long insertCourseDetails(CourseBean cbean) throws FeedbackException {
		// TODO Auto-generated method stub
		return fmsDao.insertCourseDetails(cbean);
	}
	@Override
	public FeedbackBean getFeedbackByTrainingCode(long trainingCode)
			throws FeedbackException {
		// TODO Auto-generated method stub
		return fmsDao.getFeedbackByTrainingCode(trainingCode);
	}
	@Override
	public FeedbackBean getFeedbackByParticipantId(long participantId)
			throws FeedbackException {
		// TODO Auto-generated method stub
		return fmsDao.getFeedbackByParticipantId(participantId);
	}
	@Override
	public int insertDetails(TrainingBean training) throws FeedbackException {
		// TODO Auto-generated method stub
		return fmsDao.insertDetails(training);
	}

}
