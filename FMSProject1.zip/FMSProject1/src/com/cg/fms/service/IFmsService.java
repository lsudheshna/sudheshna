package com.cg.fms.service;

import java.util.List;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.bean.TrainingBean;
import com.cg.fms.exception.FeedbackException;

public interface IFmsService {

	/*Admin Methods*/
	List<EmployeeBean> getEmployeeId(String skill)throws FeedbackException;
	public long insertCourseDetails(CourseBean cbean)throws FeedbackException;
	public FeedbackBean getFeedbackByTrainingCode(long trainingCode)throws FeedbackException;
	public FeedbackBean getFeedbackByParticipantId(long participantId)throws FeedbackException;
	/*Participants Methods*/
	int insertFeedback(FeedbackBean feedback) throws FeedbackException;
	
	/*Coordinator*/
	public int insertDetails(TrainingBean training) throws FeedbackException;

}
