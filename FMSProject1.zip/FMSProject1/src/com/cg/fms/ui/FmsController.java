package com.cg.fms.ui;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.bean.TrainingBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.service.FmsServiceImpl;
import com.cg.fms.service.IFmsService;

public class FmsController 
{
	static Scanner sc=new Scanner(System.in);
	static IFmsService fmsSer = new FmsServiceImpl();
	static EmployeeBean ebean=null;
	public static void main(String[] args)
	{		
		System.out.println("\n Enter your role");
		System.out.println("\n 1.Training  Admin "
				+"\n 2.Co-coordinator "
				+"\n 3.Participant"
				+"\n 4.Exit");
		int role=sc.nextInt();

		switch(role)
		{
		case 1:
		{
			getAdmin();
			break;
		}
		case 2:
		{
			insertDetails();
			break;
		}
		case 3:
		{
			fmsSer=new FmsServiceImpl();
			System.out.println("Enter training code: ");
			long trainingCode = sc.nextLong();

			System.out.println("Enter participant id: ");
			long participantId = sc.nextLong();

			System.out.println("Feedback Form "
					+ "\n Rate the question according to following criteria"
					+ "\n 5-Excellent: Ideal way of doing it"
					+ "\n 4-Good: No pain areas or concern but could have been better"
					+ "\n 3-Average: There are concerns but not significant"
					+ "\n 2-Below Average: Needs improvement and is salvageable"
					+ "\n 1-Poor: This way of doing things must change");

			System.out.println("Presentation and communication skills of faculty");
			int presentComm = sc.nextInt();

			System.out.println("Ability to clarify doubts and explain difficult points");
			int clarifyDoubt = sc.nextInt();

			System.out.println("Time management in completing the contents");
			int timeManage = sc.nextInt();

			System.out.println("Handout provided(Student Guide)");
			int handOut = sc.nextInt();

			System.out.println("Hardware, software and network availability");
			int hardSoftNet = sc.nextInt();

			System.out.println("Please give comments");
			sc.nextLine();
			String comments = sc.nextLine();


			System.out.println("Please give some suggestions?");
			sc.nextLine();
			String suggestions = sc.nextLine(); 

			FeedbackBean feedback = 
					new FeedbackBean(trainingCode,participantId,presentComm,clarifyDoubt,timeManage,handOut,hardSoftNet,comments,suggestions);

			try 
			{
				int dataInserted = fmsSer.insertFeedback(feedback);
				if(dataInserted == 1)
				{
					System.out.println("Details entered into feedback_master.");
				}
				else
				{
					System.out.println("Sorry could not enter details.");
				}
			} 
			catch (FeedbackException e) 
			{
				System.out.println(e.getMessage());
			}

			break;
		}
		default:
			System.exit(0);
			break;

		}


	}

	private static void insertDetails() {
		fmsSer=new FmsServiceImpl();
		System.out.println("\n 1.Training Program maintenance "
				+"\n 2.Participant Enrollment "
				+"\n 3.View Feedback report"
				+"\n 4.Exit");
		int trainingChoice=sc.nextInt();

		switch(trainingChoice)
		{
		case 1:
		{
			System.out.println("Enter Course code: ");
			long ccode=sc.nextLong();
			System.out.println("Enter Faculty code: ");
			long fcode=sc.nextLong();
			System.out.println("Enter Start date: ");
			String sdate =sc.next();
			LocalDate startdate=LocalDate.parse(sdate);
			System.out.println("Enter End date: ");
			String edate =sc.next();
			LocalDate enddate=LocalDate.parse(edate);
			TrainingBean training=new TrainingBean();
			training.setCourseCode(ccode);
			training.setFacultyCode(fcode);	
			training.setStartDate(startdate);
			training.setEndDate(enddate);
			int dataAdded=0;
			try {
				dataAdded = fmsSer.insertDetails(training);
			} 
			catch (FeedbackException e) {

				System.out.println("Problem while inserting into Training_master");
			}
			if(dataAdded==1)
			{
				System.out.println("Data added");
			}
			else
			{
				System.out.println("May be some exception"
						+ "while addition");
			}
			break;
		}
		case 2:
		{

			break;
		}
		case 3:
		{
			break;
		}
		case 4:
			System.exit(0);
			break;


		}

	}

	private static void getAdmin() {
		System.out.println("1. Faculty skill Maintenance\n"
				+ "2. Course Maintenance\n"
				+ "3. View Feedback Report\n"
				+ "4. Exit");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			getFacultySkillMaintanance();
			break;
		case 2:
			getCourseMaintanance();
			break;
		case 3:
			viewFeedbackReport();
			break;
		case 4:
			System.exit(0);
			break;
			
		}
	}
	private static void getFacultySkillMaintanance()
	{
		System.out.println("Enter skill");
		String skill=sc.next();
		try
		{
			
			List<EmployeeBean> empList=fmsSer.getEmployeeId(skill);
			for(EmployeeBean e:empList)
			{
				System.out.println(e);
			}
		} 
		catch (FeedbackException e)
		{
			System.out.println("Some Exception occurs while fetching data");
			e.printStackTrace();
		}	
		
	}
	private static void getCourseMaintanance() 
	{
		CourseBean cbean=new CourseBean();
		System.out.println("Enter Course Name: ");
		String cname= sc.next();
		System.out.println("Enter Duration of Course: ");
		int cduration= sc.nextInt();
		cbean.setCourseName(cname);
		cbean.setNoOfDays(cduration);
		try 
		{
			Long courseId=fmsSer.insertCourseDetails(cbean);
		} 
		catch (FeedbackException e) 
		{
			
			e.printStackTrace();
		}
		
		
	}

	private static void viewFeedbackReport() {
		// TODO Auto-generated method stub
		
	}

	

}
