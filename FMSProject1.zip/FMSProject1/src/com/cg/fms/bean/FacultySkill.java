package com.cg.fms.bean;
/* Name                                      Null?    Type
 ----------------------------------------- -------- -------------------
 FACULTY_ID                                         NUMBER(5)
 SKILL_SET                                          VARCHAR2(200)
 */
public class FacultySkill 
{
	private long facultyId;
	private String skillSet;
	public FacultySkill() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FacultySkill(long facultyId, String skillSet) {
		super();
		this.facultyId = facultyId;
		this.skillSet = skillSet;
	}
	public long getFacultyId() {
		return facultyId;
	}
	public void setFacultyId(long facultyId) {
		this.facultyId = facultyId;
	}
	public String getSkillSet() {
		return skillSet;
	}
	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}
	

}
