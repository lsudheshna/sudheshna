package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.bean.TrainingBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.util.DBUtil;


public class FmsDaoImpl implements IFmsDao {

	Connection conn;
	PreparedStatement pst;
	ResultSet rs;
	Statement st;
	
	@Override
	public int insertFeedback(FeedbackBean feedback) throws FeedbackException {
		conn = DBUtil.getConnection();
		int dataInserted;
		try 
		{
			
			pst = conn.prepareStatement(QueryMapper.INSERT_PARTICIPANT_FB);
			pst.setLong(1, feedback.getTrainingCode());
			pst.setLong(2, feedback.getParticipantId());
			pst.setInt(3, feedback.getPresentComm());
			pst.setInt(4, feedback.getClarifyDoubt());
			pst.setInt(5, feedback.getTimeManage());
			pst.setInt(6, feedback.getHandOut());
			pst.setInt(7, feedback.getHardSoftNet());
			pst.setString(8, feedback.getComments());
			pst.setString(9, feedback.getSuggestions());
			
			dataInserted = pst.executeUpdate();
		} 
		catch (Exception e) 
		{
			throw new FeedbackException("Problem in inserting feedback details: "+e.getMessage());
		}
		
		return dataInserted;
	}

	@Override
	public List<EmployeeBean> getEmployeeId(String skill)throws FeedbackException {
		List<EmployeeBean> empList= new ArrayList<EmployeeBean>();
		EmployeeBean ebean;
		try 
		{
			
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(QueryMapper.Faculty_Skill_Maintenance);
			pst.setString(1,skill);
			rs=pst.executeQuery();
		
			while(rs.next())
			{
			ebean=new EmployeeBean();
			ebean.setEmployeeId(rs.getLong("EMPLOYEE_ID"));
			ebean.setEmployeeName(rs.getString("EMPLOYEE_NAME"));
			ebean.setRole(rs.getString("ROLE"));
			ebean.setSkillSet(rs.getString("SKILL_SET"));
			empList.add(ebean);
			}
		}
		catch (Exception e)
		{
			throw new FeedbackException("Problem in fetching EmployeeId"+e.getMessage());

		}
		return empList;
	}

	@Override
	public long insertCourseDetails(CourseBean cbean) throws FeedbackException {
		cbean.setCourseId(generateCourseId());
		try 
		{
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(QueryMapper.Course_Maintenance);
			pst.setLong(1,cbean.getCourseId());
			pst.setString(2,cbean.getCourseName());
			pst.setLong(3,cbean.getNoOfDays());
			pst.executeUpdate();
		}
		catch (Exception e)
		{
			throw new FeedbackException("Problem in inserting CourseDetails"+e.getMessage());

		}
		return cbean.getCourseId();
	}

	@Override
	public FeedbackBean getFeedbackByTrainingCode(long trainingCode)
			throws FeedbackException {
		FeedbackBean fbean=null;	
		try 
		{
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(QueryMapper.View_Feedback_Report_By_ParticipantId);
			pst.setLong(1, trainingCode);
			rs=pst.executeQuery();
			if(rs.next())
			{
				fbean=new FeedbackBean();
				fbean.setTrainingCode(rs.getLong("training_code"));
				fbean.setParticipantId(rs.getLong("participant_id"));
				fbean.setPresentComm(rs.getInt("fb_prs_comm"));
				fbean.setClarifyDoubt(rs.getInt("fb_clrfy_dbts"));
				fbean.setTimeManage(rs.getInt("fb_tm"));
				fbean.setHandOut(rs.getInt("fb_hand_out"));		
				fbean.setHardSoftNet(rs.getInt("fb_hw_sw_ntwrk"));
				fbean.setComments(rs.getString("comments"));
				fbean.setSuggestions(rs.getString("suggestions"));
				
			}
			else
			{
				throw new FeedbackException("Feedback not filled");
			}

		}
		catch (Exception e)
		{

			throw new FeedbackException("Problem in fetching Feedback based on TrainingCode"+e.getMessage());

		} 
		return fbean;
	}

	@Override
	public FeedbackBean getFeedbackByParticipantId(long participantId)
			throws FeedbackException {
		FeedbackBean fbean=null;	
		try 
		{
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(QueryMapper.View_Feedback_Report_By_ParticipantId);
			pst.setLong(1, participantId);
			rs=pst.executeQuery();;
			if(rs.next())
			{
				fbean=new FeedbackBean();
				fbean.setTrainingCode(rs.getLong("training_code"));
				fbean.setParticipantId(rs.getLong("participant_id"));
				fbean.setPresentComm(rs.getInt("fb_prs_comm"));
				fbean.setClarifyDoubt(rs.getInt("fb_clrfy_dbts"));
				fbean.setTimeManage(rs.getInt("fb_tm"));
				fbean.setHandOut(rs.getInt("fb_hand_out"));		
				fbean.setHardSoftNet(rs.getInt("fb_hw_sw_ntwrk"));
				fbean.setComments(rs.getString("comments"));
				fbean.setSuggestions(rs.getString("suggestions"));
				
			}
			else
			{
				throw new FeedbackException("Feedback not filled By Participant");
			}

		}
		catch (Exception e)
		{

			throw new FeedbackException("Problem in fetching Feedback from Participant"+e.getMessage());

		} 
		return fbean;
	}
	
	private long generateCourseId() throws FeedbackException 
	{
		long courseId=0;
		try 
		{
			conn=DBUtil.getConnection();
			st=conn.createStatement();
			rs=st.executeQuery(QueryMapper.selectsequence);
			rs.next();
			courseId=rs.getLong(1);

		}
		catch (Exception e) 
		{
			throw new FeedbackException("Problem in generating sequence"+e.getMessage());
		}
		return courseId;
	}
/****************************Coordinator*************************************/
	@Override
	public int insertDetails(TrainingBean training) throws FeedbackException {
		training.setTrainingCode(generateTrainingCode());
		 int dataAdded;
		
		try
		{
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(QueryMapper.TRAINING_MASTER_INSERT_QUERY);
			pst.setLong(1, training.getTrainingCode());
			pst.setLong(2, training.getCourseCode());
			pst.setLong(3, training.getFacultyCode());
			pst.setDate(4, Date.valueOf(training.getStartDate()));
			pst.setDate(5, Date.valueOf(training.getEndDate()));
		
			dataAdded =pst.executeUpdate();
		//	System.out.println("data: "+dataAdded);
		} 
		catch (Exception e) 
		{
			throw new FeedbackException(e.getMessage());
		} 
		finally
		{
			try 
			{
				pst.close();
				conn.close();
			} 
			catch (Exception e) 
			{
				
				throw new FeedbackException(e.getMessage());
			}
		}
		return dataAdded;
	}
	
	private long generateTrainingCode()  throws FeedbackException 
	{
			long tcode;
			String qry = "SELECT seq_training_code.NEXTVAL FROM DUAL";
	        conn=DBUtil.getConnection();
			try
			{
			Statement st=conn.createStatement();
			ResultSet rst=st.executeQuery(qry);
			rst.next();
			tcode=rst.getLong(1);
		    }
			catch(Exception e)
			{
			throw new FeedbackException("Problem in generating purchaseid:"+e.getMessage());
		    }
			finally
			{
				try 
				{
					rs.close();
					st.close();
					conn.close();  
				} 
				catch (Exception e) 
				{
					throw new FeedbackException(e.getMessage());
				}
			}
			return tcode;
	}

}
