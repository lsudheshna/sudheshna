package com.capgemini.fms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Employee;
import com.capgemini.fms.bean.TrainingProgram;
import com.capgemini.fms.exception.FeedbackException;
import com.capgemini.fms.logging.MyLogger;
import com.capgemini.fms.queries.TrainingQueries;
import com.capgemini.fms.util.DBUtil;

public class CoordinatorDaoImpl implements CoordinatorDao {

	Connection con;
	public Logger log = MyLogger.getLog();

	public CoordinatorDaoImpl() {
		con = DBUtil.getConnect();
		if (con != null) {
			log.info("obtained connection");
		}
	}

	@Override
	public int addTrainingProgarm(TrainingProgram trainingProgram)
			throws FeedbackException {
		int courseId = trainingProgram.getCourseID();
		Course course = getCourse(courseId);
		int trainingProgramId = 0;
		Date startDate = Date.valueOf(trainingProgram.getStartDate());
		LocalDate endDate = trainingProgram.getStartDate().plusDays(
				course.getDaysOfCourse());
		
		try {
			PreparedStatement pstmt = con.prepareStatement(TrainingQueries.addTrainingProgram);
			pstmt.setInt(1, course.getCourseId());
			pstmt.setInt(2, trainingProgram.getFacultyCode());
			pstmt.setDate(3, startDate);
			pstmt.setDate(4, Date.valueOf(endDate));

			int row = pstmt.executeUpdate();
			if (row == 1) {

				trainingProgramId = getTrainingId();

				log.info("Training Progarm id :" + trainingProgramId);
			} else

				throw new FeedbackException("sorry for Incovinience");

		}
		catch (Exception e) {
			log.error(e.getMessage());
			System.out.println(e.getMessage());
		}
		
		return trainingProgramId;
	}

	public int getTrainingId() {
		int trainingId = 0;
		
		try {
			Statement stmt = con.createStatement();
			ResultSet result = stmt.executeQuery(TrainingQueries.getTrainingId);
			if (result.next()) {
				trainingId = result.getInt(1);
			}
		} catch (SQLException e) {
			log.error(e.getMessage());
			System.out.println(e.getMessage());

		}
		return trainingId;
	}

	public HashMap<Integer, Course> getcourseNames() {
		HashMap<Integer, Course> courses = new HashMap<Integer, Course>();
		try {
			int i = 0;
			Statement stmt = con.createStatement();
			ResultSet result = stmt.executeQuery(TrainingQueries.getCourseName);
			while (result.next()) {
				Course course = new Course();

				course.setCourseId(result.getInt(1));
				course.setCourseName(result.getString(2));
				course.setDaysOfCourse(result.getInt(3));
				i++;
				courses.put(i, course);
			}
			if (courses.size() != 0) {
				log.info("returning Hashmap = ");
				log.info(courses);
			}

		} catch (SQLException e) {
			log.error(e.getMessage());
			try {
				throw new FeedbackException(e.getMessage());
			} catch (FeedbackException e1) {
				e1.printStackTrace();
			}
		}

		return courses;

	}

	public Course getCourse(int courseId) {
		Course course = null;
		try {
			PreparedStatement pstmt = con.prepareStatement(TrainingQueries.getCourseById);
			pstmt.setInt(1, courseId);
			ResultSet result = pstmt.executeQuery();
			if (result.next()) {
				course = new Course();

				course.setCourseId(result.getInt(1));
				course.setCourseName(result.getString(2));
				course.setDaysOfCourse(result.getInt(3));

			}

		} catch (SQLException e) {
			log.error(e.getMessage());
			try {
				throw new FeedbackException(e.getMessage());
			} catch (FeedbackException e1) {

				e1.printStackTrace();
			}
		}

		return course;

	}

	public HashMap<Integer, Employee> getFaculties() {
		HashMap<Integer, Employee> faculties = new HashMap<Integer, Employee>();
		try {
			int i = 0;
			Statement stmt = con.createStatement();
			ResultSet result = stmt.executeQuery(TrainingQueries.getFaculties);
			while (result.next()) {
				Employee employee = new Employee();

				employee.setEmployeeId(result.getInt(1));
				;
				employee.setEmployeeName(result.getString(2));
				i++;
				faculties.put(i, employee);
			}
			if (faculties.size() != 0) {
				log.info("returning Hashmap = ");
				log.info(faculties);
			}

		} catch (SQLException e) {
			log.error(e.getMessage());
			try {
				throw new FeedbackException(e.getMessage());
			} catch (FeedbackException e1) {
				e1.printStackTrace();
			}
		}

		return faculties;

	}

	@Override
	public void updateTraining(TrainingProgram trainingProgram)
			throws FeedbackException {
		int courseId = trainingProgram.getCourseID();
		Course course = getCourse(courseId);
		PreparedStatement pstmt;
		try {
			pstmt = con.prepareStatement(TrainingQueries.updateTraining);
			pstmt.setInt(1, courseId);
			pstmt.setInt(2, trainingProgram.getFacultyCode());
			Date startDate = Date.valueOf(trainingProgram.getStartDate());
			pstmt.setDate(3, startDate);
			int days = course.getDaysOfCourse();
			Date endDate = Date.valueOf(trainingProgram.getStartDate()
					.plusDays(days));
			pstmt.setDate(4, endDate);

			pstmt.setInt(5, trainingProgram.getTraining_code());

			int row = pstmt.executeUpdate();
			if (row == 1) {
				System.out.println("Training Updated Successfully!!");
				log.info("Training updated " + trainingProgram);
			} else {
				throw new FeedbackException("Some Error Occured");
			}

		} catch (SQLException e) {

			throw new FeedbackException(e.getMessage());

		}

	}

	public TrainingProgram getTrainingById(int trainingId) {
		TrainingProgram trainingProgram = null;
		try {
			PreparedStatement pstmt = con.prepareStatement(TrainingQueries.getTrainingByid);
			pstmt.setInt(1, trainingId);
			ResultSet result = pstmt.executeQuery();
			if (result.next()) {
				trainingProgram = new TrainingProgram();

				trainingProgram.setTraining_code(result.getInt(1));
				;
				trainingProgram.setCourseID(result.getInt(2));
				trainingProgram.setFacultyCode(result.getInt(3));
				LocalDate startDate = result.getDate(4).toLocalDate();
				trainingProgram.setStartDate(startDate);
				trainingProgram.setEndDate(result.getDate(5).toLocalDate());

			}

		} catch (SQLException e) {
			log.error(e.getMessage());
			try {
				throw new FeedbackException(e.getMessage());
			} catch (FeedbackException e1) {

				e1.printStackTrace();
			}

		}
		return trainingProgram;
	}

	@Override
	public void deleteTrainingProgarm(int trainingId)
			throws FeedbackException {

		try {
			PreparedStatement pstmt = con.prepareStatement(TrainingQueries.deleteTraining);
			pstmt.setInt(1, trainingId);
			int row = pstmt.executeUpdate();
			if (row == 1) {
				System.out.println("Training Program with id : " + trainingId
						+ " Deleted");
				log.info("training program deleted" + trainingId);
			}

		} catch (Exception e) {
			log.error(e.getMessage());
		}
	}

	@Override
	public void addParticipant(String courseName, int employeeId)
			throws FeedbackException {
		int output = 0;
		int trainingCode = getTrainingCodeCourse(courseName);
		System.out.println(trainingCode);

		try {
			PreparedStatement pstmt = con.prepareStatement(TrainingQueries.addParticipant);

			String sql = "select * from training_enrollment where participantId=?";
			
			PreparedStatement pstmt1 = con.prepareStatement(sql); 
			pstmt1.setInt(1, employeeId);
			output = pstmt1.executeUpdate();
			
			if(output==0)
			{
				
			pstmt.setInt(1, trainingCode);
			pstmt.setInt(2, employeeId);

			int row = pstmt.executeUpdate();
			
			if (row == 1) {
				System.out.println("Participant added");
				log.info("Participant added :");
			} else

				throw new FeedbackException("sorry for Incovinience");
			}else{
				throw new Exception("Participant already added");
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			System.err.println(e.getMessage());
		}

	}

	public int getTrainingCodeCourse(String courseName)
			throws FeedbackException {
		int trainingCode = 0;
		try {
			PreparedStatement pstmt = con.prepareStatement(TrainingQueries.getTrainingCodeCourse);
			pstmt.setString(1, courseName);
			ResultSet result = pstmt.executeQuery();
			if (result.next()) {
				trainingCode = result.getInt(1);
			}

		} catch (SQLException e) {
			log.error(e.getMessage());
			try {
				throw new FeedbackException(e.getMessage());
			} catch (FeedbackException e1) {

				System.out.println("some error");
			}
		}
		return trainingCode;
	}

}
