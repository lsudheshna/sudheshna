package com.capgemini.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;

import com.capgemini.fms.bean.ReportBean;
import com.capgemini.fms.exception.FeedbackException;
import com.capgemini.fms.util.DBUtil;
import com.capgemini.fms.logging.MyLogger;

public class ReportDaoImpl implements ReportDao {
	Connection con = DBUtil.getConnect();
	public Logger log = MyLogger.getLog();
	int trainingCode = 0;
	int prsTotal = 0;
	int clarifyDbtsTotal = 0;
	int fbTmTotal = 0;
	int fbHndTotal = 0;
	int hwSwTotal = 0;
	int count = 0;

	@Override
	public ArrayList<ReportBean> getAllTrainingReport(int month,int pId)
			throws FeedbackException {
		ArrayList<ReportBean> reports = new ArrayList<ReportBean>();
		String sql = "Select training_code from TRAINING_PROGRAM where Extract(month from startdate) = ? ";

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, month);
			ResultSet result = pstmt.executeQuery();

			while (result.next()) {
				int trainingId = result.getInt(1);
				System.out.println(trainingId);
				ReportBean report = getAverageReport(trainingId,pId);
				report.setDate(getStartDate(trainingId));
				report.setFacultyName(getFacultyName(trainingId));
				reports.add(report);
			}

		} catch (SQLException e) {
			log.error(e.getMessage());
			throw new FeedbackException(e.getMessage());
		}

		return reports;
	}

	public ReportBean getAverageReport(int trainingId,int pId) throws FeedbackException {
		ReportBean report = null;

		String sql = "SELECT Training_code,fb_prs_comm,fb_clrfy_dbts,fb_tm,fb_hnd_out,fb_hw_sw_ntwrk FROM FEEDBACK_MASTER where Training_code = ? and participantid=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, trainingId);
			pstmt.setInt(2, pId);
			ResultSet result = pstmt.executeQuery();
			boolean flag = false;
			
			while (result.next()) {
				
				trainingCode = result.getInt(1);
				prsTotal += result.getInt(2);
				clarifyDbtsTotal += result.getInt(3);
				fbTmTotal += result.getInt(4);
				fbHndTotal += result.getInt(5);
				hwSwTotal += result.getInt(6);
				count++;
				flag = true;
			}
			report = new ReportBean();
			report.setTrainingCode(trainingId);

			if (flag) {
				report.setFbPrsComm(prsTotal / count);
				report.setFbClrfyDbts(clarifyDbtsTotal / count);
				report.setFbTM(fbTmTotal / count);
				report.setFbHndOut(fbHndTotal / count);
				report.setFbHwSwNtwrk(hwSwTotal / count);
				prsTotal = 0;
				clarifyDbtsTotal = 0;
				fbTmTotal = 0;
				fbHndTotal = 0;
				hwSwTotal = 0;
				count = 0;
			}

		} catch (SQLException e) {
			log.error(e.getMessage());
			throw new FeedbackException("Something went Wrong. try again");
			// e.printStackTrace();
		}

		return report;
	}

	public LocalDate getStartDate(int trainingId) throws FeedbackException {
		LocalDate date = null;
		String sql = "Select startdate from TRAINING_PROGRAM where training_code = ?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, trainingId);
			ResultSet result = pstmt.executeQuery();
			if (result.next()) {
				date = result.getDate(1).toLocalDate();
			}

		} catch (SQLException e) {
			log.error(e.getMessage());
			throw new FeedbackException(e.getMessage());
		}
		return date;
	}

	public String getFacultyName(int trainingId) throws FeedbackException {
		String facultyName = null;
		String sql = "Select EmployeeName from EMPLOYEE_MASTER where Employee_ID = (select FacultyID from TRAINING_PROGRAM where training_code=?)";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, trainingId);
			ResultSet result = pstmt.executeQuery();
			if (result.next()) {
				facultyName = result.getString(1);
			}

		} catch (SQLException e) {
			log.error(e.getMessage());
			throw new FeedbackException(e.getMessage());
		}

		return facultyName;

	}

	public ArrayList<ReportBean> getFacultyReport(int facultyId, int month)
			throws FeedbackException {
		ArrayList<ReportBean> reports = new ArrayList<ReportBean>();
		String sql = "Select training_code from TRAINING_PROGRAM where Extract(month from startdate) = ? AND Facultyid = ?";

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, month);
			pstmt.setInt(2, facultyId);
			ResultSet result = pstmt.executeQuery();
			while (result.next()) {
				int trainingId = result.getInt(1);
				ReportBean report = facultyWiseReport(trainingId);
				report.setDate(getStartDate(trainingId));
				reports.add(report);
			}
		} catch (SQLException e) {
			log.error(e.getMessage());
			throw new FeedbackException(e.getMessage());
		}

		return reports;
	}

	public ReportBean facultyWiseReport(int trainingId)
			throws FeedbackException {
		ReportBean report = null;

		String sql = "select Training_code,fb_prs_comm,fb_clrfy_dbts,fb_tm,fb_hnd_out,fb_hw_sw_ntwrk from FEEDBACK_MASTER where Training_code  = ?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, trainingId);
			ResultSet result = pstmt.executeQuery();
			boolean flag = false;
			while (result.next()) {
				trainingCode = result.getInt(1);
				prsTotal += result.getInt(2);
				clarifyDbtsTotal += result.getInt(3);
				fbTmTotal += result.getInt(4);
				fbHndTotal += result.getInt(5);
				hwSwTotal += result.getInt(6);
				count++;
				flag = true;
			}
			report = new ReportBean();
			report.setTrainingCode(trainingId);

			if (flag) {
				report.setFbPrsComm(prsTotal / count);
				report.setFbClrfyDbts(clarifyDbtsTotal / count);
				report.setFbTM(fbTmTotal / count);
				report.setFbHndOut(fbHndTotal / count);
				report.setFbHwSwNtwrk(hwSwTotal / count);
				prsTotal = 0;
				clarifyDbtsTotal = 0;
				fbTmTotal = 0;
				fbHndTotal = 0;
				hwSwTotal = 0;
				count = 0;
			}

		} catch (SQLException e) {
			log.error(e.getMessage());
			throw new FeedbackException("Something went Wrong. try again");
			// e.printStackTrace();
		}

		return report;

	}

	public ArrayList<ReportBean> getDefaulterReport(int month, int pId)
			throws FeedbackException {
		ArrayList<ReportBean> reports = new ArrayList<ReportBean>();
		String sql = "Select training_code from TRAINING_PROGRAM where Extract(month from startdate) = ?";

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, month);
			
			ResultSet result = pstmt.executeQuery();
			while (result.next()) {
				int trainingId = result.getInt(1);
				ArrayList<ReportBean> temp = getReports(trainingId,pId);
				if (!temp.isEmpty()) {
					Iterator<ReportBean> it = temp.iterator();
					while (it.hasNext()) {
						ReportBean report = (ReportBean) it.next();
						if (report != null) {
							report.setDate(getStartDate(trainingId));
							report.setFacultyName(getFacultyName(trainingId));
							report.setParticipantName(getParticipantName(
									trainingId, report.getParticipantId()));
							reports.add(report);
						}
					}
				}
			}

		} catch (SQLException e) {
			log.error(e.getMessage());
			throw new FeedbackException(e.getMessage());
		}

		return reports;
	}

	public ArrayList<ReportBean> getReports(int trainingId,int pId)
			throws FeedbackException {
		ArrayList<ReportBean> tempReports = new ArrayList<ReportBean>();
		int participantId = 0;

		String sql = "SELECT Training_code,ParticipantId,fb_prs_comm,fb_clrfy_dbts,fb_tm,fb_hnd_out,fb_hw_sw_ntwrk FROM FEEDBACK_MASTER where Training_code = ? and participantid=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, trainingId);
			pstmt.setInt(2, pId);
			ResultSet result = pstmt.executeQuery();
			while (result.next()) {
				participantId = result.getInt(2);
				if ((prsTotal = result.getInt(3)) == 0
						|| (clarifyDbtsTotal = result.getInt(4)) == 0
						|| (fbTmTotal = result.getInt(5)) == 0
						|| (fbHndTotal = result.getInt(6)) == 0
						|| (hwSwTotal = result.getInt(7)) == 0) 
				{
					ReportBean report = new ReportBean();
					report.setTrainingCode(trainingId);
					report.setParticipantId(participantId);
					report.setFbPrsComm(prsTotal);
					report.setFbClrfyDbts(clarifyDbtsTotal);
					report.setFbTM(fbTmTotal);
					report.setFbHndOut(fbHndTotal);
					report.setFbHwSwNtwrk(hwSwTotal);
					tempReports.add(report);	
				}
			}

		} catch (SQLException e) {
			log.error(e.getMessage());
			throw new FeedbackException("Something went Wrong. try again");
			// e.printStackTrace();
		}
		return tempReports;
	}

	public String getParticipantName(int trainingId, int participantId)
			throws FeedbackException {
		String participantName = null;
		String sql = "Select EmployeeName from EMPLOYEE_MASTER Where Employee_id = (Select ParticipantId from TRAINING_ENROLLMENT where training_code = ? AND ParticipantId = ?)";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, trainingId);
			pstmt.setInt(2, participantId);
			ResultSet result = pstmt.executeQuery();
			if (result.next()) {
				participantName = result.getString(1);
			}
		} catch (SQLException e) {
			log.error(e.getMessage());
			throw new FeedbackException("Something went Wrong. try again");
			// e.printStackTrace();
		}
		return participantName;
	}

}
