package com.capgemini.fms.ui;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Employee;
import com.capgemini.fms.bean.Faculty;
import com.capgemini.fms.exception.FeedbackException;
import com.capgemini.fms.service.AdminService;
import com.capgemini.fms.service.AdminServiceImpl;

public class AdminHelper {
	static AdminService service = new AdminServiceImpl();
	BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

	public AdminHelper() {
		displayWelcomePage();
	}

	// Welcome page function with valid login credentials

	public void displayWelcomePage() {

		boolean flag = false;
		try {
			do {
				System.out
						.println("--------------------FeedBack Management System--------------------");
				System.out.println("1. Login");
				System.out.println("0. Exit");

				int choice = Integer.parseInt(reader.readLine());

				switch (choice) {
				case 1:
					displayLogin();
					break;

				case 0:
					reader.close();
					System.out.println("ThankYou for using Feedback Management System!");
					System.exit(0);
					break;
				default:
					System.err.println("Invalid Choice.Enter Again");
					flag = true;
					break;
				}
			} while (flag);
		} catch (NumberFormatException e) {
			System.err.println("Input Cannot contain Characters only numbers");
			displayWelcomePage();
		} catch (Exception e) {
			System.err.println(e.getMessage());

			// displayWelcomePage();
		}
	}

	/*
	 * Function when option selected is 1 : which ask for employee id and
	 * password
	 */

	public void displayLogin() {
		boolean flag = false;
		try {
			do {
				System.out.print("Enter Employee Id: ");
				int employeeId = Integer.parseInt(reader.readLine());
				System.out.print("\nEnter password: ");
				String password = reader.readLine();

				String role = service.getUser(employeeId, password);

				switch (role) {
				case "Admin":
					displayAdminHome();
					break;

				case "Coordinator":
					new CoordinatorHelper();
					break;

				case "Participant":
					new ParticipantHelper(employeeId);
					break;
				default:
					System.err.println("No user exists ");
					flag = true;
					break;
				}
			} while (flag);
		} catch (NumberFormatException e) {
			System.err.println("Input Cannot contain Characters only numbers");
			displayLogin();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			displayWelcomePage();
		}
	}

	// Validates based on Admin role and respective operations are displayed

	public void displayAdminHome() {
		boolean flag = false;
		try {
			System.out
					.println("--------------------WELCOME TO ADMIN HOME--------------------");
			do {
				System.out.println("\n1. Faculty Maintenence.");
				System.out.println("2. Course Maintenence.");
				System.out.println("3. View Feedback.");
				System.out.println("0. Logout");

				int choice = Integer.parseInt(reader.readLine());

				switch (choice) {
				case 1:
					displayFacultyMaintainenceMenu();
					break;

				case 2:
					displayCourseMaintainenceMenu();
					break;
				case 3:
					new ReportHelper();
					displayAdminHome();
					break;

				case 0:
					displayWelcomePage();
					break;
				default:
					System.err.println("Invalid Choice.Enter Again");
					flag = true;
					break;
				}
			} while (flag);
		} catch (NumberFormatException e) {
			System.err.println("Input Cannot contain Characters only numbers");
			displayAdminHome();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			displayWelcomePage();
		}
	}

	// Faculty-maintenance menu is displayed with respective functionalities

	private void displayFacultyMaintainenceMenu() {

		boolean flag = false;
		try {
			do {
				System.out
						.println("******************Select Option******************");
				System.out.println("1. Search By Id.");
				System.out.println("2. View All");
				System.out.println("0. Back");

				int choice = Integer.parseInt(reader.readLine());

				switch (choice) {
				case 1:
					displayEmployeeForm();
					break;

				case 2:
					displayAllEmployees();
					break;

				case 0:
					displayAdminHome();
					break;
				default:
					System.err.println("Invalid Choice.Enter Again");
					flag = true;
					break;
				}
			} while (flag);
		} catch (NumberFormatException e) {
			System.err.println("Input Cannot contain Characters only numbers\n");
			displayFacultyMaintainenceMenu();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			displayAdminHome();
		}

	}

	// Employee credentials are retrieved , displayed and suitable skill-set is
	// assigned

	private void displayEmployeeForm() {
		String skillSet = "";

		boolean flag = false;
		try {
			int employeeId = 0;
			do {
				try {
					System.out.println("Enter Faculty ID :");
					employeeId = Integer.parseInt(reader.readLine());
				} catch (NumberFormatException e) {
					System.err
							.println("Input Cannot contain Characters only numbers");
					displayEmployeeForm();
				}
				Employee employee = service.getEmployeeById(employeeId);
				if (employee == null) {
					throw new FeedbackException("Invalid ID.Try Again");
				} else if (employee.getRole().equals("Coordinator")) {
					boolean flag1 = true;
					while (flag1) {
						System.out
								.println("***************Employee Details***************");
						System.out.println("Employee Id : "
								+ employee.getEmployeeId());
						System.out.println("Employee Name : "
								+ employee.getEmployeeName());
						System.out.println("Employee Role : "
								+ employee.getRole());

						System.out
								.println("Do you want to enter Skill set for this Employee?  (Y/N)");
						String check = reader.readLine().toUpperCase();
						switch (check) {

						case "Y":
							String choose = null;
							do {
								System.out.println("Enter SkillSet:");
								skillSet += reader.readLine() + ",";
								System.out
										.println("Do you want to enter More SkillSets ? (Y/N)");
								boolean flag3 = true;
								while (flag3) {
									choose = reader.readLine().toUpperCase();
									if (choose.equals("N")
											|| choose.equals("Y")) {
										if (choose.equals("N")) {
											Faculty faculty = new Faculty();
											faculty.setFacultyId(employee
													.getEmployeeId());
											faculty.setSkillset(skillSet);
											service.addSkillSet(faculty);
											System.out
													.println("SkillSet Added for Employee with name "
															+ employee
																	.getEmployeeName()
															+ " !!");
											
										}
										flag3 = false;
									} else {
										System.err
												.println("Invalid Choice.Enter again");
										flag3 = true;
									}
								}

							} while (choose.equals("Y"));
							displayFacultyMaintainenceMenu();
							break;
						case "N":
							displayFacultyMaintainenceMenu();
							break;
						default:
							System.err.println("Invalid Choice.");
							flag = true;
							break;
						}

					}
				} else {
					throw new FeedbackException(
							"This not faculty. Please Enter a valid faculty ID");
				}
				flag = true;
			} while (flag);
		} catch (Exception e) {
			System.err.println(e.getMessage());
			displayEmployeeForm();
		}
	}

	// Employee credentials are retrieved and displayed with role

	public void displayAllEmployees() {
		boolean flag = false;
		try {
			do {
				HashMap<Integer, Employee> emmployees = service.getEmployees();
				Set<Integer> keys = emmployees.keySet();
				for (Integer key : keys) {
					System.out.println(key + " . "
							+ emmployees.get(key).getEmployeeName() + " . "
							+ emmployees.get(key).getRole());
				}
				displayEmployeeForm();
			} while (flag);
		} catch (Exception e) {
			System.err.println(e.getMessage());
			displayFacultyMaintainenceMenu();
		}
	}

	// Course-maintenance menu is displayed with respective functionalities

	private void displayCourseMaintainenceMenu() {
		boolean flag = false;
		try {
			do {
				System.out.println("1. Add Course.");
				System.out.println("2. View All Courses.");
				System.out.println("3. Update Course.");
				System.out.println("4. Delete Course.");
				System.out.println("0. Back.");

				int choice = Integer.parseInt(reader.readLine());

				switch (choice) {
				case 1:
					displayCourseForm();
					break;

				case 2:
					Map<Integer, Course> courses = service.getCourses();
					System.out.println("Course Id\tCourse Name\tNo Of Days");
					Set<Integer> keys = courses.keySet();
					for (Integer key : keys) {
						Course course = courses.get(key);
						System.out.println(course.getCourseId() + "\t\t"
								+ course.getCourseName() + "\t\t"
								+ course.getDaysOfCourse());
					}
					System.out.println("Enter any key to Go Back..");
					String dummy = reader.readLine();
					displayCourseMaintainenceMenu();
					break;
				case 3:
					displayUpdateForm();
					break;

				case 4:
					displayDeleteForm();
					break;
				case 0:
					displayAdminHome();
					break;
				default:
					System.err.println("Invalid Choice.Enter Again");
					flag = true;
					break;
				}
			} while (flag);
		} catch (NumberFormatException e) {
			System.err.println("Input Cannot contain Characters only numbers");
			displayCourseMaintainenceMenu();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			displayAdminHome();

		}
	}

	// display Form to ask Course Details and call the service method for
	// deleting record

	private void displayDeleteForm() {

		boolean flag = false;
		try {
			do {
				System.out.println("Enter CourseId:");
				int courseId = Integer.parseInt(reader.readLine());
				Map<Integer, Course> courses = service.getCourses();
				if (courses.containsKey(courseId)) {
					Course course = courses.get(courseId);
					System.out.println("Course Id :" + course.getCourseId());
					System.out
							.println("Course Name :" + course.getCourseName());
					System.out.println("No of days :"
							+ course.getDaysOfCourse());
					System.out
							.println("\nDo you Want to Delete the Course? (Y/N)");
					String check = reader.readLine().toUpperCase();
					switch (check) {

					case "Y":
						service.deleteCourse(courseId);
						displayCourseMaintainenceMenu();
						break;
					case "N":
						displayCourseMaintainenceMenu();
						break;
					default:
						System.err.println("Invalid Choice.Enter Again");
						flag = true;
						break;
					}
				} else {
					throw new FeedbackException("No such id exists");
				}
			} while (flag);
		} catch (NumberFormatException e) {
			System.err.println("Input Cannot contain Characters only numbers");
			displayDeleteForm();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			displayCourseMaintainenceMenu();
		}

	}

	// display Form to ask Course Details and call the service method

	private void displayCourseForm() {
		boolean flag = false;
		boolean flag4 = true;
		int noOfDays=0;
		try {
			do {
				System.out.println("Do you Want to Add a new Course? (Y/N)");
				String check = reader.readLine().toUpperCase();
				switch (check) {

				case "Y":
					System.out.println("Enter Course Name:");
					String courseName = reader.readLine();
					do
					{System.out
							.println("Enter Number of days the course will be :");
					
					try {
						noOfDays = Integer.parseInt(reader.readLine());
						flag4=false;
					} catch (Exception e) {
						System.err.println("Days should be in numbers");
					}}while(flag4);
					Course course = new Course();
					course.setCourseName(courseName);
					course.setDaysOfCourse(noOfDays);
					int id = service.addCourse(course);
					System.out.println("Course Added with id " + id);
					flag = true;
					break;
				case "N":
					displayCourseMaintainenceMenu();
					break;
				default:
					System.err.println("Invalid Choice.Enter Again");
					flag = true;
					break;
				}
			} while (flag);
		} catch (Exception e) {
			System.err.println(e.getMessage());
			displayCourseMaintainenceMenu();
		}
	}

	// User interaction for updating credentials

	private void displayUpdateForm() {
		try {
			System.out
					.println("Do you Want to Continue? Enter 'Y' to continue or any other key to go back");

			String check = reader.readLine().toUpperCase();
			switch (check) {
			case "Y":
				displayUpdateDetailsForm();
				break;
			default:
				displayCourseMaintainenceMenu();
				break;
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
			displayCourseMaintainenceMenu();
		}

	}

	// display form to ask details for updating course.

	private void displayUpdateDetailsForm() {
		boolean flag = false;
		try {
			do {
				System.out.println("Enter CourseId:");
				int courseId = Integer.parseInt(reader.readLine());
				Map<Integer, Course> courses = service.getCourses();
				if (courses.containsKey(courseId)) {
					Course course = courses.get(courseId);
					System.out.println("Course Id :" + course.getCourseId());
					System.out
							.println("Course Name :" + course.getCourseName());
					System.out.println("No of days :"
							+ course.getDaysOfCourse());
					System.out
							.println("\nDo you Want to Update the Course? (Y/N)");
					String check = reader.readLine().toUpperCase();
					switch (check) {

					case "Y":
						System.out
								.println("Do you want to update the name of the course ? ('Y' for Yes any other key for No");
						check = reader.readLine().toUpperCase();
						if (check.equals("Y")) {
							System.out.println("Enter new Course Name:");
							String courseName = reader.readLine();
							course.setCourseName(courseName);
						}
						System.out
								.println("Do you want to update the number of days of the course ? ('Y' for Yes any other key for No");
						check = reader.readLine().toUpperCase();
						if (check.equals("Y")) {
							System.out
									.println("Enter Number of days the course will be :");
							int noOdDays = Integer.parseInt(reader.readLine());
							course.setDaysOfCourse(noOdDays);
						}
						service.updateCourse(course);
						displayCourseMaintainenceMenu();
						break;
					case "N":
						displayCourseMaintainenceMenu();
						break;
					default:
						System.err.println("Invalid Choice.Enter Again");
						flag = true;
						break;
					}
				} else {
					throw new FeedbackException("No such Id exists");
				}
			} while (flag);
		} catch (NumberFormatException e) {
			System.err
					.println("Input Cannot contain Characters only numbers:Please filll all details again carefully!!");
			displayUpdateDetailsForm();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			displayCourseMaintainenceMenu();
		}
	}

}
