package com.capgemini.fms.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Set;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Employee;
import com.capgemini.fms.bean.TrainingProgram;
import com.capgemini.fms.exception.FeedbackException;
import com.capgemini.fms.service.CoordinatorService;
import com.capgemini.fms.service.CoordinatorServiceImpl;
import com.capgemini.fms.service.TrainingValidation;

public class CoordinatorHelper {

	static CoordinatorService service = new CoordinatorServiceImpl();
	static HashMap<Integer, Course> courses = service.getcourseNames();
	static HashMap<Integer, Employee> faculties = service.getFaculties();
	BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	static int choice = 0;
	static int courseSelected = 0;
	static int facultySelected = 0;

	static TrainingProgram trainingProgram = null;

	public CoordinatorHelper() {
		displayCoordinatorHome();
	}

	//Validates based on Coordinator role and respective operations are displayed

	
	public void displayCoordinatorHome() {
		boolean flag = false;
		try {
			do {
				System.out.println("\n*************Enter your choice*************");
				System.out.println("1. Training Program Maintainence.");
				System.out.println("2. Participant Enrollment.");
				System.out.println("3. View Feedback.");
				System.out.println("0. Logout");

				int choice = Integer.parseInt(reader.readLine());

				switch (choice) {
				case 1:
					displayTrainingMaintenance();
					break;

				case 2:
					displayParticipantEnrollment();
					break;
				case 3:
					new ReportHelper();
					displayCoordinatorHome();
					break;

				case 0:
					new AdminHelper();
					break;
				default:
					System.err.println("Invalid Choice.Enter Again");
					flag = true;
					break;
				}
			} while (flag);
		} catch (NumberFormatException e) {
			System.err.println("Input Cannot contain Characters only numbers");
			displayCoordinatorHome();
		} catch (Exception e) {
		}
	}

	//Training-maintenance menu is displayed with respective functionalities
	
	public void displayTrainingMaintenance() {
		boolean flag = false;
		try {
			do {
				System.out.println("\n*************Training Program Maintenance*************");
				System.out.println("1.Add Training Program Appointment");
				System.out.println("2.Update Training Program ");
				System.out.println("3.Delete Training Program ");
				System.out.println("0.Back");
				System.out.println("enter your choice: ");
				choice = Integer.parseInt(reader.readLine());
				switch (choice) {
				case 1:
					addTraining();
					break;

				case 2:
					updateTraining();
					break;

				case 3:
					deleteTraining();
					break;
				case 0:
					displayCoordinatorHome();
					break;
				default:
					flag = true;
					System.err.println("enter valid choice");
					break;
				}
			} while (flag);
		} catch (NumberFormatException e) {
			System.err.println("Input Cannot contain Characters only numbers\n");
			displayTrainingMaintenance();
		} catch (IOException e) {

			System.err.println(e.getMessage());
			displayCoordinatorHome();
		}

	}

	//display Form for training Details and call the service method for deleting record

	
	private void deleteTraining() throws IOException {

		try {
			System.out
					.println("Enter the Id of the Training Program you wish to delete ..");
			int trainingId = Integer.parseInt(reader.readLine());
			service.deleteTrainingProgarm(trainingId);
			displayTrainingMaintenance();
		} catch (NumberFormatException e) {
			System.err.println("Input Cannot contain Characters only numbers");
			deleteTraining();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			displayTrainingMaintenance();
		}
	}

	//display Form for training Details and call the service method for updating record

	private void updateTraining() {

		try {
			System.out
					.println("enter the training Id for which you want to update the training details");
			int trainingId = Integer.parseInt(reader.readLine());
			trainingProgram = service.getTrainingById(trainingId);
			System.out
					.println("do you want to update course? Enter 'Y' for yes or any other key for No");

			String selectedChoice = reader.readLine().toUpperCase();
			switch (selectedChoice) {
			case "Y":
				System.out.println("The Courses available are : ");
				displayCourse();
				choice = Integer.parseInt(reader.readLine());
				if (choice > courses.size()) {
					throw new FeedbackException(
							"No such course.. select course from above list");

				}
				courseSelected = courses.get(choice).getCourseId();
				System.out.println(courses.size());
				trainingProgram.setCourseID(courseSelected);
				updateFaculty();
				break;
			default:
				updateFaculty();
				break;
			}

			System.out
					.println("do you want to update Date for the course? Enter 'Y' for yes or any other key for No");
			selectedChoice = reader.readLine().toUpperCase();
			switch (selectedChoice) {
			case "Y":
				boolean flag = false;
				String startdate;
				LocalDate stdate;
				do {
					do {
						System.out.println("Enter Start Date");
						startdate = reader.readLine();
					} while (!TrainingValidation.checkDate(startdate));
					DateTimeFormatter formatter = DateTimeFormatter
							.ofPattern("dd/MM/yyyy");
					stdate = LocalDate.parse(startdate, formatter);
					if (validateDate(stdate)) {
						System.err
								.println("Training date cannot be less tha todays date.Enter again");
						flag = true;
					}else{
						flag = false;
						trainingProgram.setStartDate(stdate);
					}
				} while (flag);

				break;
			default:
				break;
			}
			service.updateTraining(trainingProgram);
			displayTrainingMaintenance();
		} catch (NumberFormatException e) {
			System.err.println("Input Cannot contain Characters only numbers");
			updateTraining();
		} catch (Exception e) {

			updateTraining();
		}
	}

	//display Form for training Details and call the service method for updating faculty
	
	public void updateFaculty() {
		try {
			System.out
					.println("do you want to update Faculty for the course? Enter 'Y' for yes or any other key for No");
			String selectedChoice = reader.readLine().toUpperCase();
			switch (selectedChoice) {
			case "Y":
				System.out.println("The Faculties available are : ");
				displayFaculties();
				choice = Integer.parseInt(reader.readLine());
				if (choice > faculties.size()) {
					System.out
							.println("Enter Valid number .. select number from list displayed above");
				}
				facultySelected = faculties.get(choice).getEmployeeId();
				trainingProgram.setFacultyCode(facultySelected);
				break;
			default:
				break;
			}
		} catch (NumberFormatException e) {
			System.err.println("Input Cannot contain Characters only numbers");
			updateFaculty();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			updateTraining();
		}

	}

	//display Form for training Details and call the service method for inserting record
	
	private void addTraining() {
		LocalDate stdate = null;
		int choiceCourse=0;
		int choiceFaculty=0;
		boolean flag4 = true;
		boolean flag5 = true;
		try {
			do{
			System.out.println("------Adding an Training------");

			System.out.println("select the Course you are interested in");
	
			
				displayCourse();

				try {
					choiceCourse = Integer.parseInt(reader.readLine());
					if (choiceCourse > courses.size()) {
						throw new FeedbackException(
								"No such course...");
					}
					flag4 = false;
				} catch (Exception e) {
					System.err.println("Please Select the correct choice\n");
				}
			}while(flag4);
			
			
			courseSelected = courses.get(choiceCourse).getCourseId();
			
			do{
			System.out
					.println("select the faculty that you would like to assign to this course :");
			displayFaculties();
			
			
			
			try {
				choiceFaculty = Integer.parseInt(reader.readLine());
				if (choiceFaculty > faculties.size()) {
					throw new FeedbackException(
							"Enter Valid number .. select nmber from list displayed above");
				}
				flag5 = false;
			} catch (Exception e) {
				System.out.println("Please enter the correct choice");
			}
			}while(flag5);
			facultySelected = faculties.get(choiceFaculty).getEmployeeId();

			String startdate;
			boolean flag = false;
			do {
				do {
					System.out.println("Enter Start Date in (dd/MM/yyyy) format");
					startdate = reader.readLine();
				} while (!TrainingValidation.checkDate(startdate));
				DateTimeFormatter formatter = DateTimeFormatter
						.ofPattern("dd/MM/yyyy");
				stdate = LocalDate.parse(startdate, formatter);
				if (validateDate(stdate)) {
					System.err
							.println("Training date cannot be less than todays date.Enter again");
					flag = true;
				}else{
					flag = false;
				}
				
			} while (flag);

			trainingProgram = new TrainingProgram();
			trainingProgram.setCourseID(courseSelected);
			trainingProgram.setFacultyCode(facultySelected);
			trainingProgram.setStartDate(stdate);
			int trainingId = 0;
			trainingId = service.addTrainingProgarm(trainingProgram);

			System.out
					.println("Your Training Progarm has been successfully Registered, "
							+ "your Progarm ID is  " + trainingId);
			displayTrainingMaintenance();
		} catch (NumberFormatException e) {
			System.err.println("Input Cannot contain Characters only numbers");
			addTraining();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			displayTrainingMaintenance();
		}

	}

	//display Form for trainee Details and call the service method for validating record
	
	private boolean validateDate(LocalDate stdate) {
		LocalDate currentDate = LocalDate.now();
		if (currentDate.compareTo(stdate) > 0)
			return true;
		else
			return false;
	}

	//display Form for trainee Details and call the service method for displaying record
	
	public static void displayCourse() {
		Set<Integer> keys = courses.keySet();

		for (Integer key : keys) {
			System.out.println(key + ". " + courses.get(key).getCourseName());
		}

	}

	//display Form for trainee Details and call the service method for dispalying faculty record

	public static void displayFaculties() {

		Set<Integer> keys = faculties.keySet();

		for (Integer key : keys) {
			System.out.println(key + ". "
					+ faculties.get(key).getEmployeeName());
		}
	}

	//display Form for trainee Details and call the service method for displaying record

	public void displayParticipantEnrollment() {
		try {

			System.out.println("1.Add participant ");
			System.out.println("0.Back");
			System.out.println("enter your choice: ");
			choice = Integer.parseInt(reader.readLine());
			switch (choice) {
			case 1:
				addParticipant();
				break;
			case 0:
				displayCoordinatorHome();
				break;
			default:
				System.err.println("Invalid choice : Enter again");
				displayParticipantEnrollment();
				break;

			}
		} catch (NumberFormatException e) {
			System.err.println("Input Cannot contain Characters only numbers");
			displayParticipantEnrollment();
		} catch (IOException e) {
			System.err.println(e.getMessage());
			displayCoordinatorHome();
		}
	}

	//display Form for trainee Details and call the service method for inserting record

	
	private void addParticipant() {
		try {
			System.out
					.println("select the training in which you are interested");
			displayCourse();

			int choiceCourse = Integer.parseInt(reader.readLine());
			String courseName = courses.get(choiceCourse).getCourseName();
			System.out.println(courseName);
			System.out.println("Enter Employee Id");
			int empId = Integer.parseInt(reader.readLine());
			try {
				service.addParticipant(courseName, empId);
				displayParticipantEnrollment();
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		} catch (NumberFormatException e) {
			System.err.println("Input Cannot contain Characters only numbers");
			addParticipant();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			displayParticipantEnrollment();
		}
	}

}
