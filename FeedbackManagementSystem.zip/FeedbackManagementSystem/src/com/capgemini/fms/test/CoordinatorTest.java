package com.capgemini.fms.test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.junit.Test;

import com.capgemini.fms.bean.TrainingProgram;
import com.capgemini.fms.dao.CoordinatorDaoImpl;
import com.capgemini.fms.exception.FeedbackException;

public class CoordinatorTest {

	TrainingProgram trainingProgram = new TrainingProgram();
	CoordinatorDaoImpl coordinator = new CoordinatorDaoImpl();

	@Test
	public void addTrainingProgarm() {
		
		DateTimeFormatter formatter = DateTimeFormatter
				.ofPattern("dd/MM/yyyy");
		LocalDate startDate = LocalDate.parse("28/11/2017", formatter);
	
		LocalDate endDate = LocalDate.parse("28/12/2018", formatter);
		
		trainingProgram.setCourseID(1000);
		trainingProgram.setEndDate(endDate);
		trainingProgram.setFacultyCode(10002);
		trainingProgram.setStartDate(startDate);

		try {
			assertNotNull(coordinator.addTrainingProgarm(trainingProgram));
		} catch (FeedbackException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getTrainingId(){
		
		assertNotNull(coordinator.getTrainingId());
	}
	
	@Test
	public void getTrainingById(){
		assertNotNull(coordinator.getTrainingById(1001));
	}
	
	@Test
	public void getTrainingCodeCourse(){
		
		try {
			assertEquals(1001, coordinator.getTrainingCodeCourse("J2EE"));
		} catch (FeedbackException e) {
			e.printStackTrace();
		}
	}

}
