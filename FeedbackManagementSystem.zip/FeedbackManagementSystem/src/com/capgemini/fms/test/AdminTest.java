package com.capgemini.fms.test;

import static org.junit.Assert.*;
import org.junit.Test;
import com.capgemini.fms.bean.Employee;
import com.capgemini.fms.dao.AdminDao;
import com.capgemini.fms.dao.AdminDaoImpl;
import com.capgemini.fms.exception.FeedbackException;

public class AdminTest {
	AdminDao dao = new AdminDaoImpl();
	AdminDaoImpl admin = new AdminDaoImpl();
	Employee employee = new Employee();

	@Test
	public void testGetSkillset() throws FeedbackException {
		assertEquals("java j2ee, mhb,hhh,", admin.getSkillset(10002));
	}

	@Test
	public void testGetEmployeeById() {

		employee.setEmployeeId(10003);
		employee.setEmployeeName("Pallavi");
		employee.setRole("Participant");
		try {

			assertEquals(employee, admin.getEmployeeById(10003));
		} catch (FeedbackException e) {

			e.printStackTrace();
		}
	}

	@Test
	public void testGetUser() throws FeedbackException {
		assertEquals("Participant", admin.getUser(10004, "prachi"));
	}

	@Test
	public void testGetCourses() throws FeedbackException {
		assertNotNull(admin.getCourses());
	}

}